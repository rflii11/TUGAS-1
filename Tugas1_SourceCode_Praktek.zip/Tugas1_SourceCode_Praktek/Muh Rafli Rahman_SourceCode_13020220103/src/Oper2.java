/*
Nim  : 13020220103
Nama : Muh Rafli Rahman
--Sabtu, 22/02/2024--
 */
public class Oper2 {
    public static void main(String[] args) {
        char i, j;
        i = 3;
        j = 4;

        System.out.println("i = "+ (int) i);
        System.out.println("j = "+ j);
        System.out.println("i & j = "+ (i & j));
        System.out.println("i | j = "+ (i | j));
        System.out.println("i ^ j = "+ (i ^ j));
        System.out.println(Math.pow(i, j));
        System.out.println("~i = "+ ~i);
    }
}

/*
Nim  : 13020220103
Nama : Muh Rafli Rahman
--Sabtu, 22/02/2024--
 */
public class Oper3 {
    public static void main(String[] args) {
        if (true && true){ System.out.println(true && true);}
        if (true & true) { System.out.println(true & false); }
        if (true){ System.out.println(true); }
        if (true || true){ System.out.println(true);}
        if (true|false) { System.out.println(true|false); }
    }
}

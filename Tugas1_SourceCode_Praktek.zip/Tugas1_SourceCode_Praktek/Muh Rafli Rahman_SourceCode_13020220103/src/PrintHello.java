/*
Nim  : 13020220103
Nama : Muh Rafli Rahman
--Sabtu, 22/02/2024--
 */
public class PrintHello {
    public static void main(String[] args) {
        System.out.print("Hello");
        System.out.print("\nHello ");
        System.out.println("World");
        System.out.println("Welcome");
    }
}

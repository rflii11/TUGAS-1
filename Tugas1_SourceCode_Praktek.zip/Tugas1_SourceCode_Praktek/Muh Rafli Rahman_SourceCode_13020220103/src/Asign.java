/*
Nim  : 13020220103
Nama : Muh Rafli Rahman
--Sabtu, 22/02/2024--
 */
public class Asign {
    public static void main (String[] args){
        int i;
        System.out.print("Hello\n"); i = 5;
        System.out.println("Ini nilai i : " + i);
    }
}

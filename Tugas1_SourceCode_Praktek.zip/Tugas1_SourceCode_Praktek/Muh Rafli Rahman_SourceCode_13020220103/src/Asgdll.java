/*
Nim  : 13020220103
Nama : Muh Rafli Rahman
--Sabtu, 22/02/2024--
 */
public class Asgdll {
    public static void main(String[] args){
        float f=20.0f;
        double fll;

        fll=10.0f;
        System.out.println("f : "+f+ "\nfll: "+fll);
    }
}
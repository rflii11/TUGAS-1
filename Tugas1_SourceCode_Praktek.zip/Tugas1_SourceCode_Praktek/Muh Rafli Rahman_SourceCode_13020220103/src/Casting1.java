/*
Nim  : 13020220103
Nama : Muh Rafli Rahman
--Sabtu, 22/02/2024--
 */
public class Casting1 {
    public static void main(String[] args){
        int a=5, b=6;
        float d=2.f, e=3.2f;
        char g='5';
        double k=3.14;
        System.out.println((float)a);
        System.out.println((double)b);
        System.out.println((int)d);
        System.out.println((double)e);
        System.out.println((int)g);
        System.out.println((float)g);
        System.out.println((double)g);
        System.out.println((int)k);
        System.out.println((float)k);
    }
}

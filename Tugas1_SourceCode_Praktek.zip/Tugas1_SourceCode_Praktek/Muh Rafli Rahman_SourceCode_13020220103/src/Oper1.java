/*
Nim  : 13020220103
Nama : Muh Rafli Rahman
--Sabtu, 22/02/2024--
 */
public class Oper1 {
    public static void main(String[] args) {
        int n = 10;
        int x = 1;
        int y = 2;

        System.out.println ("n = "+ n);
        System.out.println ("x = "+ x);
        System.out.println ("y = "+ y);
        System.out.println("n & 8 = "+ (n & 8));
        System.out.println ("x & ~ 8 = "+ (x & ~8));
        System.out.println ("y << 2 = "+ (y << 2));
        System.out.println ("y >> 3 = "+ (y >>3));
    }
}

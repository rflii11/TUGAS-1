/*
Nim  : 13020220103
Nama : Muh Rafli Rahman
--Sabtu, 22/02/2024--
 */
public class incr {
    public static void main(String[] args) {
        int i, j;
        i = 3;
        j = i++;
        System.out.println ("Nilai i : " + (++i) + "\nNilai j : " + j);
    }
}
